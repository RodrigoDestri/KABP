1 - Execute o app "KABP.exe" em modo administrador.
2 - Informe a porta a ser fechada.
3 - Clique em "Kill Port".
4 - Receba a mensagem de sucesso ou erro.